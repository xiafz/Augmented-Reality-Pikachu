package com.example.xiafz.hellovisionworld;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.Toast;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.calib3d.Calib3d;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.DMatch;
import org.opencv.core.KeyPoint;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.MatOfDMatch;
import org.opencv.core.MatOfKeyPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.features2d.DescriptorExtractor;
import org.opencv.features2d.DescriptorMatcher;
import org.opencv.features2d.FeatureDetector;
import org.opencv.features2d.Features2d;
import org.opencv.imgproc.Imgproc;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;


public class HelloVisionActivity extends AppCompatActivity implements CameraBridgeViewBase.CvCameraViewListener2 {
    // image processing member variable declaration
    private Bitmap targetImage;
    private Mat cameraFrame;
    private Mat targetFrame;
    private Mat greyFrame;
    private Mat outputFrame;
    private Size sz;
    private  FeatureDetector featureDetector;
    private  MatOfKeyPoint keyPoints_target;
    private  MatOfKeyPoint keyPoints_frame;
    private  DescriptorExtractor descriptorExtractor;
    private  DescriptorMatcher descriptorMatcher;
    private Mat descriptor_target;
    private Mat descriptor_frame;
    private MatOfDMatch goodMatch;
    private DescriptorMatcher matcher;
    private MatOfDMatch matches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Log.i(TAG, "called onCreate");
        super.onCreate(savedInstanceState);
        getWindow().addFlags
                (WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_hello_vision);

        Intent intent = new Intent(Intent.ACTION_PICK, Uri.parse("content://media/internal/images/media"));
        startActivityForResult(intent, 0);


        mOpenCvCameraView = (CameraBridgeViewBase)
                findViewById(R.id.HelloVisionView);
//Set the view as visible
        mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);
//Register your activity as the callback object to handle
//camera frames
        mOpenCvCameraView.setCvCameraViewListener(this);
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0 && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            //To speed up loading of image
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;

            sz = new Size(1280, 720); // Resize the matrix for output
            greyFrame = new Mat();
            cameraFrame = new Mat();
            outputFrame = new Mat();
            //Obtain reszied image in the Mat format
            Bitmap temp = BitmapFactory.decodeFile(picturePath, options);
            targetImage = temp.copy(Bitmap.Config.ARGB_8888, false);
            targetFrame = new Mat(targetImage.getWidth(), targetImage.getHeight(), CvType.CV_8UC3);
            Utils.bitmapToMat(targetImage, targetFrame);
            Imgproc.resize(targetFrame, targetFrame , sz);
            Imgproc.cvtColor(targetFrame,targetFrame,Imgproc.COLOR_RGB2GRAY);

        }
    }

    public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {
        //Add opencCV code here for vision processing
        //Test following 2 lines of code for edge detection (comment out recognize() function)
        //Imgproc.cvtColor(cameraFrame,greyFrame,Imgproc.COLOR_RGB2GRAY);
        //Imgproc.Canny(greyFrame,outputFrame,10,100);

        //customized recgonize function for handling video frames
        recognize(inputFrame.rgba());
        return outputFrame;
    }

    public void recognize(Mat inputFrame) {
        //convert color
        cameraFrame = inputFrame;
        Imgproc.cvtColor(cameraFrame,greyFrame,Imgproc.COLOR_RGB2GRAY);

        //detect features
        featureDetector.detect(greyFrame, keyPoints_frame);
        featureDetector.detect(targetFrame, keyPoints_target);
        //extract feature descriptors
        descriptorExtractor.compute(targetFrame, keyPoints_target, descriptor_target);
        descriptorExtractor.compute(greyFrame, keyPoints_frame,descriptor_frame );
        //check for number of features to ensure the descripotrMatcher have something to work with
        Integer target_rows = descriptor_target.rows();
        Integer frame_rows = descriptor_frame.rows();
        if ((target_rows.intValue()  > 3) && (frame_rows.intValue() > 3)) {
            descriptorMatcher.match(descriptor_target, descriptor_frame, matches);

            //matching detection determination starts here
            List<DMatch> matchesList = matches.toList();

            //find the minimum distance
            Double max_dist = 0.0;
            Double min_dist = 100000.0; //might need to be initialized with bigger values
            for (int i = 0; i < descriptor_target.rows(); i++) {
                Double dist = (double) matchesList.get(i).distance;
                if (dist < min_dist) min_dist = dist;
                if (dist > max_dist) max_dist = dist;
            }

            //find the good matches
            LinkedList<DMatch> good_matches = new LinkedList<DMatch>();
            Double descriptor_distance = 0.0;
            for (int i = 0; i < descriptor_target.rows(); i++) {
                descriptor_distance = (double) matchesList.get(i).distance;
                if (descriptor_distance < 3*min_dist) {
                    good_matches.addLast(matchesList.get(i));
                }
            }
            goodMatch.fromList(good_matches);

            //display matches in 2 images for debugging purpose only
            // need to resize the output frame for display
//            Features2d.drawMatches(
//                    targetFrame,
//                    keyPoints_target,
//                    greyFrame,
//                    keyPoints_frame,
//                    goodMatch,
//                    outputFrame);
//
//            Imgproc.resize(outputFrame, outputFrame, sz);

            // find good matches
            LinkedList<Point> targetList = new LinkedList<Point>();
            LinkedList<Point> frameList = new LinkedList<Point>();
            List<KeyPoint> keypoints_targetList = keyPoints_target.toList();
            List<KeyPoint> keypoints_frameList = keyPoints_frame.toList();

            // ensure we have enough points for finding homography
            Integer good_match_found = good_matches.size();
            if (good_match_found>5) {
                //generate homography input variables
                for (int i = 0; i < good_matches.size(); i++) {
                    targetList.addLast(keypoints_targetList.get(good_matches.get(i).queryIdx).pt);
                    frameList.addLast(keypoints_frameList.get(good_matches.get(i).trainIdx).pt);
                }

                MatOfPoint2f targetPoint2f = new MatOfPoint2f();
                MatOfPoint2f framePoint2f = new MatOfPoint2f();
                targetPoint2f.fromList(targetList);
                framePoint2f.fromList(frameList);

                //find homography
                Mat hg = Calib3d.findHomography(targetPoint2f, framePoint2f, Calib3d.RANSAC, 3);

                //define overlay rectangle shape
                Mat target_corners = new Mat(4, 1, CvType.CV_32FC2);
                Mat frame_corners = new Mat(4, 1, CvType.CV_32FC2);
                target_corners.put(0, 0, new double[]{0, 0});
                target_corners.put(1, 0, new double[]{targetFrame.cols(), 0});
                target_corners.put(2, 0, new double[]{targetFrame.cols(), targetFrame.rows()});
                target_corners.put(3, 0, new double[]{0, targetFrame.rows()});

                //apply prospective projection
                Core.perspectiveTransform(target_corners, frame_corners, hg);


                //draw the lines
                Imgproc.line(outputFrame, new Point(frame_corners.get(0, 0)), new Point(frame_corners.get(1, 0)), new Scalar(0, 255, 0), 4);
                Imgproc.line(outputFrame, new Point(frame_corners.get(1, 0)), new Point(frame_corners.get(2, 0)), new Scalar(0, 255, 0), 4);
                Imgproc.line(outputFrame, new Point(frame_corners.get(2, 0)), new Point(frame_corners.get(3, 0)), new Scalar(0, 255, 0), 4);
                Imgproc.line(outputFrame, new Point(frame_corners.get(3, 0)), new Point(frame_corners.get(0, 0)), new Scalar(0, 255, 0), 4);
                //resize the images
                Imgproc.resize(inputFrame, outputFrame, sz);
                //print the text of detection status
                Imgproc.putText(outputFrame, "Good", new Point(10, 50), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(0, 255, 0), 4);
                Imgproc.putText(outputFrame, "target: "+target_rows.toString(), new Point(10, 100), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
                Imgproc.putText(outputFrame, "frame: "+frame_rows.toString(), new Point(10, 150), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
                Imgproc.putText(outputFrame, "good_match: "+good_match_found.toString(), new Point(10, 200), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
                Imgproc.putText(outputFrame, "distance threshold: "+min_dist.toString(), new Point(10, 250), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);

                //the homography can be further processed to obtain translation and rotation vector for projection
                //the vectors identified can be used for rendering with OpenglES for fancy AR effects
                //the following link illustrate a way to find prospective projection vector of translation and rotation
                //note that it is not currently working/tested within this context, just for reference
                //visit this link for mor information: https://www.programcreek.com/java-api-examples/?class=org.opencv.calib3d.Calib3d&method=solvePnP
            }
            else{
                //print information for not enough points for homography
                Imgproc.resize(inputFrame, outputFrame, sz);
                Imgproc.putText(outputFrame, "Not enough match for homography", new Point(10, 50), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
                Imgproc.putText(outputFrame, "target: "+target_rows.toString(), new Point(10, 100), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
                Imgproc.putText(outputFrame, "frame: "+frame_rows.toString(), new Point(10, 150), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
                Imgproc.putText(outputFrame, "good_match: "+good_match_found.toString(), new Point(10, 200), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
                Imgproc.putText(outputFrame, "distance threshold: "+min_dist.toString(), new Point(10, 250), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
            }

        }
        else {
            //print information for not enough feature points detected
            Imgproc.cvtColor(cameraFrame,outputFrame,Imgproc.COLOR_RGB2GRAY);
            Imgproc.putText(outputFrame, "Nothing Found", new Point(10, 50), Core.FONT_HERSHEY_SIMPLEX, 1, new Scalar(255, 0, 0), 4);
        }
        //Features2d.drawKeypoints(greyFrame, keyPoints_frame, outputFrame);
    }

    public void onCameraViewStopped() {

    }

    public void onCameraViewStarted(int width, int height) {
        // initialize the detectors and matchers at beginning
        featureDetector=FeatureDetector.create(FeatureDetector.ORB);
        descriptorExtractor=DescriptorExtractor.create(DescriptorExtractor.ORB);
        descriptorMatcher=DescriptorMatcher.create(6); //or change with DescriptorMatcher.BRUTEFORCE_HAMMING
        keyPoints_target = new MatOfKeyPoint();
        keyPoints_frame = new MatOfKeyPoint();
        descriptor_target = new Mat();
        descriptor_frame = new Mat();
        matcher = DescriptorMatcher.create(1); // 1 = FLANNBASED
        matches = new MatOfDMatch();
        goodMatch = new MatOfDMatch();

    }



    //A Tag to filter the log messages
    private static final String TAG = "Example::HelloVisionWorld::Activity";
    //A class used to implement the interaction between OpenCV and the
//device camera.
    private CameraBridgeViewBase mOpenCvCameraView;
    //This is the callback object used when we initialize the OpenCV
//library asynchronously
    private BaseLoaderCallback mLoaderCallback = new
            BaseLoaderCallback(this) {
                @Override
//This is the callback method called once the OpenCV
// manager is connected
                public void onManagerConnected(int status) {
                    switch (status) {
//Once the OpenCV manager is successfully connected we
// can enable the camera interaction with the defined
// OpenCV camera view
                        case LoaderCallbackInterface.SUCCESS:
                        {
                            Log.i(TAG, "OpenCV loaded successfully");
                            mOpenCvCameraView.enableView();
                        } break;
                        default:
                        {
                            super.onManagerConnected(status);
                        } break;
                    }
                }
            };

    @Override
    public void onResume(){
        super.onResume();
//Call the async initialization and pass the callback object we
//created later, and chose which version of OpenCV library to
//load. Just make sure that the OpenCV manager you installed
//supports the version you are trying to load.
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_0_0,
                this, mLoaderCallback);
        /*OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_10,
                this, mLoaderCallback);*/
    }
}

